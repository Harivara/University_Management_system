import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Aca_Prog extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton b1,b2;
	JComboBox c1;
	
	public Aca_Prog() 
	{
		super("ACADEMIC PROGRAMS");
		
		l1 = new JLabel("Select one of the options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		l2 = new JLabel("Course:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		String Aca_Pro[] = {"B.Tech(IT)","B.Tech(CS)","B.Tech(CSAI)"};
		c1 = new JComboBox(Aca_Pro);
		c1.setBackground(Color.WHITE);
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,16));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,16));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(120, 20, 300, 100);
		add(l1);
		
		l2.setBounds(110, 100, 100, 100);
		add(l2);
		
		c1.setBounds(200, 135, 190, 30);
		add(c1);
		
		b1.setBounds(130, 250, 100, 30);
		add(b1);
		
		b2.setBounds(250, 250, 100, 30);
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,150);
		setSize(500,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		
		String ac = (String)c1.getSelectedItem();
		
		if(ae.getSource()==b1) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 
		{
			if(ac == "B.Tech(IT)") 
			{
				new it().setVisible(true);
			}
			else if(ac =="B.Tech(CS)") 
			{
				new cs().setVisible(true);
			}
			else if(ac == "B.Tech(CSAI)") 
			{
				new csai().setVisible(true);
			}			
		}
	}
	public static void main(String[] args)
	{
		new Aca_Prog().setVisible(true);

	}

}


