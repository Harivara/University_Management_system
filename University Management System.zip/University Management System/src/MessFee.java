import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

class MessFee extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2,b3;
	JTextField tf1,tf2,tf3;
	public MessFee()
	{
		super("MESS FEE PORTAL");
		l1 = new JLabel("Roll Number:");
		l1.setFont(new Font("Ralewat",Font.BOLD,20));
				
		l2 = new JLabel("Amount:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("MESS FEE:");
		l3.setFont(new Font("Raleway",Font.BOLD,22));
		
		l4 = new JLabel("15000 Rupees");
		l4.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l5 = new JLabel("Phone Number:");
		l5.setFont(new Font("Ralewat",Font.BOLD,20));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		b3 = new JButton("View Payment Details");
		b3.setFont(new Font("Raleway",Font.BOLD,18));
		b3.setBackground(Color.white);
		b3.setForeground(Color.red);
		
		
		setLayout(null);
		
		
		l3.setBounds(110, 50, 600, 80);
		add(l3);
		
		l4.setBounds(240, 40, 800, 100);
		add(l4);
		
		l1.setBounds(80, 110, 300, 100);
		add(l1);
		
		l5.setBounds(80, 160, 300, 100);
		add(l5);
		
		l2.setBounds(80, 210, 200, 100);
		add(l2);
		
		tf1.setBounds(250, 148, 150, 25);
		add(tf1);
		
		tf2.setBounds(250, 198, 150, 25);
		add(tf2);
		
		tf3.setBounds(250, 247, 150, 25);
		add(tf3);
		
		b1.setBounds(100, 320, 100, 30);
		add(b1);
		
		b2.setBounds(275, 320, 100, 30);
		add(b2);
		
		b3.setBounds(120, 380, 240, 30);
		add(b3);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(400,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();
		String b = tf2.getText();
		String c = tf3.getText();
		
		try 
		{
			if(ae.getSource()==b2) 
			{
				if(tf1.getText().equals("") || tf2.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
					
					ResultSet rs = c1.s.executeQuery("select student1.PHONE_NO , messfee.ROLL_NO , AMOUNT from student1,messfee where student1.PHONE_NO = '"+b+"' and student1.ROLL_NO = '"+a+"' ;");
					
					if(rs.next()) 
					{
						String q = "INSERT INTO messfee VALUES('"+a+"','"+c+"' , '"+b+"')";
						
						c1.s.executeUpdate(q);
						
						
						JOptionPane.showMessageDialog(null, "Roll Number: " + a + "\n Amount Paid: " + c);
						
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
					}			
					
				}
			}
			else if(ae.getSource()==b1) 
			{
				new Fee_Portal().setVisible(true);
				setVisible(false);
			}
			else if(ae.getSource()==b3) 
			{
				new messpaymentdetails().setVisible(true);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
	
	
	public static void main(String[] args) 
	{
		new MessFee().setVisible(true);

	}
}

class messpaymentdetails extends JFrame implements ActionListener
{
	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","ROLL NUMBER","NAME","PHONE NUMBER","DATE","MONTH","YEAR","AMOUNT","CITY","STATE"};
	String y [][] = new String[100][20] ;
	int i=0,j=0,k=1;
	public messpaymentdetails() 
	{
		super("FEE STRUCTURE");
		
		setLocation(150,80);
		setSize(1100,500);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select student1.ROLL_NO,NAME,student1.PHONE_NO,DATE,MONTH,YEAR,AMOUNT,CITY,STATE from student1,messfee where student1.ROLL_NO = messfee.ROLL_NO and student1.PHONE_NO = messfee.phone_no order by student1.ROLL_NO;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = Integer.toString(k);
				y[i][j++] = rs.getString("student1.ROLL_NO");
				y[i][j++] = rs.getString("NAME");
				y[i][j++] = rs.getString("student1.PHONE_NO");
				y[i][j++] = rs.getString("DATE");
				y[i][j++] = rs.getString("MONTH");
				y[i][j++] = rs.getString("YEAR");
				y[i][j++] = rs.getString("AMOUNT");
				y[i][j++] = rs.getString("CITY");
				y[i][j++] = rs.getString("STATE");
				i++;
				j=0;
				k++;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.white);
		
		
		setVisible(true);
	}
		
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}catch(Exception e) 
		{
			System.out.println(e);
		}
	}
}