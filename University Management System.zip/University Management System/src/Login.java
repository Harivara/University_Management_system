import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener 
{
	JLabel l1,l2,l3,l4;
	JTextField tf1;
	JPasswordField p1;
	JButton b1,b2,b3,b4;
	
	Login()
	{
		super("LOGIN PAGE");
		
		l1 = new JLabel("Indian Institute of Information Technology Lucknow");
		l1.setFont(new Font("System",Font.BOLD,22));
		
		l2 = new JLabel("User-Id");
		l2.setFont(new Font("Arial",Font.PLAIN,20));
		
		l3 = new JLabel("Password");
		l3.setFont(new Font("Arial",Font.PLAIN,20));
		
		tf1 = new JTextField(15);
		tf1.setFont(new Font("Arial",Font.BOLD,14));
		
		p1 = new JPasswordField(15);
		p1.setFont(new Font("Arial",Font.BOLD,14));
		
		
		ImageIcon ic1 = new ImageIcon(this.getClass().getResource("/log_in.png"));
		Image i1 = ic1.getImage().getScaledInstance(18, 18, Image.SCALE_DEFAULT);
		b1 = new JButton("LOG IN",new ImageIcon(i1));
		b1.setFont(new Font("Arial",Font.BOLD,14));
		b1.setBackground(Color.WHITE);
		
		ImageIcon ic2 = new ImageIcon(this.getClass().getResource("/clear.png"));
		Image i2 = ic2.getImage().getScaledInstance(18, 18, Image.SCALE_DEFAULT);
		b2 = new JButton("CLEAR",new ImageIcon(i2));
		b2.setFont(new Font("Arial",Font.BOLD,14));
		b2.setBackground(Color.white);
		
		ImageIcon ic3 = new ImageIcon(this.getClass().getResource("/Sign_Up_As_Stu.png"));
		Image i3 = ic3.getImage().getScaledInstance(18, 18, Image.SCALE_DEFAULT);
		b3 = new JButton("SIGN-UP AS STUDENT",new ImageIcon(i3));
		b3.setFont(new Font("Arial",Font.BOLD,14));
		b3.setBackground(Color.white);
		
		ImageIcon ic4 = new ImageIcon(this.getClass().getResource("/Sign_Up_As_Tea.png"));
		Image i4 = ic4.getImage().getScaledInstance(18, 18, Image.SCALE_DEFAULT);
		b4 = new JButton("SIGN-UP AS TEACHER",new ImageIcon(i4));
		b4.setFont(new Font("Arial",Font.BOLD,14));
		b4.setBackground(Color.white);
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/Logo.png"));
		Image i5 = ic5.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l4 = new JLabel(icc5);
		
		setLayout(null);
		
		l1.setBounds(225, 100, 550, 200);		//indian institute of information tech
		add(l1);
		
		l2.setBounds(362, 240, 350, 100);		//user id
		add(l2);
		
		l3.setBounds(339, 290, 350, 100);		//pass
		add(l3);
		
		l4.setBounds(410, 30, 150, 150);		//logo	
		add(l4);
		
		tf1.setBounds(450, 275, 180, 25);
		add(tf1);
		
		p1.setBounds(450, 327, 180, 25);		
		add(p1);
		
		b1.setBounds(355, 400, 120, 30);		//login
		add(b1);
		
		b2.setBounds(515, 400, 120, 30);		//clear
		add(b2);
		
		b3.setBounds(370, 450, 250, 30);		//sign up as student
		add(b3);
		
		b4.setBounds(370, 485, 250, 30);		//sign up as teacher
		add(b4);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		
		getContentPane().setBackground(Color.white);
		
		
		setLocation(150,10);
		setSize(1000, 700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent ae) 
	{
		try 
		{
			conn c1 = new conn();
			
			String a = tf1.getText();
			char [] b = p1.getPassword();
			String c = new String(b);
			String x = "Select * from login where user_id = '"+a+"' and password ='"+c+"'";
			ResultSet rs = c1.s.executeQuery(x);
			
			if(ae.getSource()==b1) 
			{
				
				if(rs.next()==true) 
				{
					new Contents().setVisible(true);
					setVisible(false);
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Incorrect User ID or Password");	
				}
			}
			else if(ae.getSource()==b2) // clear
			{
				tf1.setText("");
				p1.setText("");
			}
			else if(ae.getSource()==b3) // sign up as student
			{
				new Sign_Up_Student().setVisible(true);
				this.setVisible(false);
			}
			else if(ae.getSource()==b4) 
			{
				new Sign_Up_Teacher().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception e) 
		{
			System.out.println("error: "+ e );
		}
	}
	public static void main(String[] args) 
	{
		new Login().setVisible(true);
	}

}

