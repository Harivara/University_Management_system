import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;


class csai extends JFrame
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16;
	public csai() 
	{
		super("ACADEMIC PROGRAMS");
		
		l1 = new JLabel("B.Tech(CSAI)");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		l2 = new JLabel("The B.Tech.(CS-AI) course has been designed to prepare an aspirant ");
		l2.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l3 = new JLabel("engineer to understand and solve core problems such as operating system ");
		l3.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l4 = new JLabel("design, software development, computer design,synthesizing electronic");
		l4.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l5 = new JLabel("devices, designing compatible algorithms,and translation of algorithms");
		l5.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l6 = new JLabel("to efficient programs. The subjects that have been included to incorporate ");
		l6.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l7 = new JLabel("these capabilities to the students are Fundamentals of Electronics ");
		l7.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l8 = new JLabel("Engineering, Digital Logic Design, Design and Analysis of Algorithms, ");
		l8.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l9 = new JLabel("Operating System, Data Structures, and R Programming. There are other ");
		l9.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l10 = new JLabel("auxiliary subjects to enhance the professional, entrepreneurial and people");
		l10.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l11 = new JLabel("skills.The knowledge and capabilities required to develop systems with ");
		l11.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l12 = new JLabel("human like intelligence will be imparted to the young aspirants through the ");
		l12.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l13 = new JLabel("subject matter in the following areas-Intelligent Database Management, ");
		l13.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l14 = new JLabel("Deep Learning, Artificial Intelligence, Big-Data Analytics, Reinforcement  ");
		l14.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l15 = new JLabel("Learning, Natural Language Processing, Machine Learning, Image and Vision ");
		l15.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l16 = new JLabel("Processing.");
		l16.setFont(new Font("Baskerville",Font.PLAIN,20));
				
		setLayout(null);
		
		l1.setBounds(280, 30, 300, 100);
		add(l1);
		
		l2.setBounds(70, 100, 650, 100);
		add(l2);
		
		l3.setBounds(70, 130, 670, 100);
		add(l3);
		
		l4.setBounds(70, 160, 680, 100);
		add(l4);
		
		l5.setBounds(70, 190, 685, 100);
		add(l5);
		
		l6.setBounds(70, 220, 685, 100);
		add(l6);
		
		l7.setBounds(70, 250, 600, 100);
		add(l7);
		
		l8.setBounds(70, 280, 680, 100);
		add(l8);
		
		l9.setBounds(70, 310, 680, 100);
		add(l9);
		
		l10.setBounds(70, 340, 680, 100);
		add(l10);
		
		l11.setBounds(70, 370, 680, 100);
		add(l11);
		
		l12.setBounds(70, 400, 680, 100);
		add(l12);
		
		l13.setBounds(70, 430, 680, 100);
		add(l13);
		
		l14.setBounds(70, 460, 680, 100);
		add(l14);
		
		l15.setBounds(70, 490, 680, 100);
		add(l15);
		
		l16.setBounds(70 ,520, 600, 100);
		add(l16);
	
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(280,20);
		setSize(800,700);
		setVisible(true);
	}
	
	public static void main(String[] args)
	{
		new csai().setVisible(true);

	}
}