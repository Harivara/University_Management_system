import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class view_details extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1,b2,b3,b4;
	public view_details()
	{
		super("VIEW DETAILS");
		
		l1 = new JLabel("Select one of the options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		b1 = new JButton("Students");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.white);
		b1.setForeground(Color.black);
		
		b2 = new JButton("Teachers");
		b2.setFont(new Font("Raleway",Font.BOLD,20));
		b2.setBackground(Color.white);
		b2.setForeground(Color.black);
		
		b3 = new JButton("Back");
		b3.setFont(new Font("Raleway",Font.BOLD,16));
		b3.setBackground(Color.BLACK);
		b3.setForeground(Color.orange);
		
		b4 = new JButton("Exit");
		b4.setFont(new Font("Raleway",Font.BOLD,16));
		b4.setBackground(Color.BLACK);
		b4.setForeground(Color.red);
		
		setLayout(null);
		
		l1.setBounds(120, 20, 300, 100);
		add(l1);
		
		b1.setBounds(140, 150, 200, 40);
		add(b1);
		
		b2.setBounds(140, 220, 200, 40);
		add(b2);
		
		b3.setBounds(140, 330, 100, 30);
		add(b3);
		
		b4.setBounds(250, 330, 100, 30);
		add(b4);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(400,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==b1) 
		{
			new students().setVisible(true);
		}
		else if(ae.getSource()==b2) 
		{
			new teachers().setVisible(true);
		}
		else if(ae.getSource()==b3) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b4) 
		{
			System.exit(0);
		}
		
		
	}

	public static void main(String[] args)
	{
		new view_details().setVisible(true);
	}

}	
	
class students extends JFrame implements ActionListener
{

	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","ROLL NUMBER","NAME","PHONE NUMBER","EMAIL ADDRESS","COURSE","BRANCH","SEM","VACCINATION STATUS","CITY","STATE"};
	String y [][] = new String[20][15] ;
	int i=0,j=0,k=1;
	public students() 
	{
		super("STUDENT DETAILS");
		
		setLocation(110,170);
		setSize(1200,400);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select student1.ROLL_NO ,NAME,student1.PHONE_NO , EMAIL_ID , COURSE , BRANCH ,SEM , VACC_STATUS , CITY , STATE from student1 , student2 where student1.ROLL_NO = student2.ROLL_NO and student1.PHONE_NO = student2.PHONE_NO order by student1.ROLL_NO ;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = Integer.toString(k);
				y[i][j++] = rs.getString("student1.ROLL_NO");
				y[i][j++] = rs.getString("NAME");
				y[i][j++] = rs.getString("student1.PHONE_NO");
				y[i][j++] = rs.getString("EMAIL_ID");
				y[i][j++] = rs.getString("COURSE");
				y[i][j++] = rs.getString("BRANCH");
				y[i][j++] = rs.getString("SEM");
				y[i][j++] = rs.getString("VACC_STATUS");
				y[i][j++] = rs.getString("CITY");
				y[i][j++] = rs.getString("STATE");
				i++;
				j=0;
				k++;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		b2 = new JButton("Back");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.black);
		
		
		setVisible(true);
		
	
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}
		catch(Exception e) 
		{
			
		}
	}

}
	

	
class teachers extends JFrame implements ActionListener
{
	
	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","Staff ID","Name","Phone Number","Email Address","Degree","Job Title","Vaccination Status","City","State"};
	String y [][] = new String[20][12] ;
	int i=0,j=0,k=1;
	public teachers() 
	{
		super("TEACHER DETAILS");
		
		setLocation(150,170);
		setSize(1100,400);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select NAME , PHONE_NO , login.user_id , EMAIL , DEGREE , JOB_TITLE , VACC_STATUS , CITY , STATE from teacher1 , login where teacher1.STAFF_ID = login.user_id order by teacher1.STAFF_ID ;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = Integer.toString(k);
				y[i][j++] = rs.getString("login.user_id");
				y[i][j++] = rs.getString("NAME");
				y[i][j++] = rs.getString("PHONE_NO");
				y[i][j++] = rs.getString("EMAIL");
				y[i][j++] = rs.getString("DEGREE");
				y[i][j++] = rs.getString("JOB_TITLE");
				y[i][j++] = rs.getString("VACC_STATUS");
				y[i][j++] = rs.getString("CITY");
				y[i][j++] = rs.getString("STATE");
				i++;
				j=0;
				k++;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		b2 = new JButton("Back");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.black);
		
		
		setVisible(true);
		
	
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}
		catch(Exception e) 
		{
			
		}
	}
}

