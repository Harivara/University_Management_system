import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Sign_Up_Student_2 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
	JTextField tf1,tf2,tf3,tf4;
	JComboBox c1,c2,c3,c4;
	JButton b1,b2;
	public Sign_Up_Student_2()
	{
		super("SIGN UP AS STUDENT-PAGE 2");
		
		l1 = new JLabel("Page 2: Additional Details");
		l1.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l2 = new JLabel("Roll Number:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l11 = new JLabel("Phone Number:");
		l11.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("Email Address:");
		l3.setFont(new Font("Raleway",Font.BOLD,20));
		
		l4 = new JLabel("Course:");
		l4.setFont(new Font("Raleway",Font.BOLD,20));
		
		l5 = new JLabel("Branch:");
		l5.setFont(new Font("Raleway",Font.BOLD,20));
		
		l6 = new JLabel("Semester:");
		l6.setFont(new Font("Raleway",Font.BOLD,20));
		
		l7 = new JLabel("Year of Graduation:");
		l7.setFont(new Font("Raleway",Font.BOLD,20));
		
		l8 = new JLabel("STUDENT SIGN UP");
		l8.setFont(new Font("Raleway",Font.BOLD,25));
		
		l9 = new JLabel("Set Password:");
		l9.setFont(new Font("Raleway",Font.BOLD,20));
		
		l10 = new JLabel("(Use min 3 characters)");
		l10.setFont(new Font("Raleway",Font.BOLD,18));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf4 = new JTextField(20);
		tf4.setFont(new Font("Arial",Font.PLAIN,18));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,16));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.WHITE);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,16));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.WHITE);
		
		String Course[] = {"B.Tech","Phd","P.G Diploma","MBA","Post Graduate"};
		c1 = new JComboBox(Course);
		c1.setBackground(Color.WHITE);
		
		String Branch[] = {"CSAI","IT","CS","CSB"};
		c2 = new JComboBox(Branch);
		c2.setBackground(Color.WHITE);
		
		String Sem[] = {"1","2","3","4","5","6","7","8"};
		c3 = new JComboBox(Sem);
		c3.setBackground(Color.WHITE);
		
		String Yog[] = {"2021","2022","2023","2024","2025","2026"}; //year of graduation
		c4 = new JComboBox(Yog);
		c4.setBackground(Color.WHITE);
		
		setLayout(null);
		
		l8.setBounds(370, 0, 250, 150);		//student sign up
		add(l8);
		
		l1.setBounds(370,60, 250,100);		//page 2 additional details
		add(l1);
		
		l2.setBounds(180, 135, 130, 100);		//roll number
		add(l2);
		
		l11.setBounds(180, 180, 180, 100);		//phone number
		add(l11);
		
		l3.setBounds(180, 225, 180, 100);		//email address
		add(l3);
		
		l4.setBounds(180, 270, 100, 100);		//course
		add(l4);
		
		l5.setBounds(180, 315, 100, 100);		//branch
		add(l5);
		
		l6.setBounds(180, 360, 100, 100);		//semester
		add(l6);
		
		l7.setBounds(180, 405, 200, 100);		//year of grad
		add(l7);
		
		l9.setBounds(180, 450, 200, 100);		//set password
		add(l9);
		
		l10.setBounds(180, 475, 200, 100);		//min 3 characters
		add(l10);
		
		tf1.setBounds(430, 170, 350, 28);
		add(tf1);
		
		tf2.setBounds(430, 217, 350, 28);
		add(tf2);
		
		tf3.setBounds(430, 260, 350	,28);
		add(tf3);
		
		tf4.setBounds(430, 490, 350, 28);
		add(tf4);
		
		c1.setBounds(430, 310, 110, 20);		//course
		add(c1);
		
		c2.setBounds(430, 355, 80, 20);			//branch
		add(c2);
		
		c3.setBounds(430, 400, 50, 20);			//sem
		add(c3);
		
		c4.setBounds(430, 445, 80, 20);		//year of grad
		add(c4);
		
		b1.setBounds(385, 570, 100, 30);		//back
		add(b1);
		
		b2.setBounds(505, 570, 100, 30);		//next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
				
		String a = tf1.getText();       //roll number
		String b = tf2.getText();		//phone number
		String c = tf3.getText();		//email
		
		String ac = (String)c1.getSelectedItem();	//course
		String bc = (String)c2.getSelectedItem();	//branch
		String cc = (String)c3.getSelectedItem();	//sem
		String dc = (String)c4.getSelectedItem();	//year of grad
		
		String d = tf4.getText();		//password	
		
		
		
		try 
		{
			if(ae.getSource()==b2) //next
			{ 
				conn c1 = new conn();
				
				if(tf3.getText().equals("") || tf1.getText().equals("") || tf2.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					try 
					{
						ResultSet rs = c1.s.executeQuery("Select * from student1 where ROLL_NO = '"+a+"' and PHONE_NO = '"+b+"';");
					
						if(rs.next()) 
						{
							
							String q1 = "INSERT INTO student2 VALUES('"+a+"','"+c+"','"+ac+"','"+bc+"','"+cc+"','"+dc+"','"+d+"' , '"+b+"');";
							String q2 = "INSERT INTO login(user_id,password) VALUES('"+a+"','"+d+"');";
								
							c1.s.executeUpdate(q1);
							c1.s.executeUpdate(q2);
								
								
							JOptionPane.showMessageDialog(null, "Login ID: " + a + "\n Password: " + d);
								
							new Contents().setVisible(true);
							setVisible(false);
							
						}
						else 
						{
							JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
						}
					}
					catch(Exception e1) 
					{
						System.out.println(e1);
					}

				}
				
				
				
				
			}
			else if(ae.getSource()==b1) //back
			{
				new Sign_Up_Student().setVisible(true);
				setVisible(false);
			}
			
			
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
	public static void main(String[] args) 
	{
		new Sign_Up_Student_2().setVisible(true);

	}

}
