import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Student_Clubs extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JButton b1,b2;
	public Student_Clubs() 
	{
		super("STUDENT CLUBS");
		
		l1 = new JLabel("Student Clubs");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		l2 = new JLabel("1.Technical Club:");
		l2.setFont(new Font("Helvetica",Font.BOLD,26));
		
		l3 = new JLabel("2.Cultural Clubs:");
		l3.setFont(new Font("Helvetica",Font.BOLD,26));
		
		l4 = new JLabel("3.Sports Society");
		l4.setFont(new Font("Helvetica",Font.BOLD,26));
		
		l5 = new JLabel("4.Entrepreneurship Cell");
		l5.setFont(new Font("Helvetica",Font.BOLD,26));
		
		l6 = new JLabel("Crotonia-Library Society");
		l6.setFont(new Font("Arial",Font.PLAIN,24));
		
		l7 = new JLabel("Zephyr-Dance Society");
		l7.setFont(new Font("Arial",Font.PLAIN,24));
		
		l8 = new JLabel("Goonj-Drama Society");
		l8.setFont(new Font("Arial",Font.PLAIN,24));
		
		l9 = new JLabel("Utkrisht-Fine Arts Society");
		l9.setFont(new Font("Arial",Font.PLAIN,24));
		
		l10 = new JLabel("After Dark-Photography Society");
		l10.setFont(new Font("Arial",Font.PLAIN,24));
		
		l11 = new JLabel("Estrella-Music Society");
		l11.setFont(new Font("Arial",Font.PLAIN,24));
		
		l12 = new JLabel("Axios-IIITL");
		l12.setFont(new Font("Arial",Font.PLAIN,24));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,16));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("Exit");
		b2.setFont(new Font("Raleway",Font.BOLD,16));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.red);
		
		setLayout(null);
		
		l1.setBounds(360, 10, 300, 100);
		add(l1);
		
		l2.setBounds(200, 90, 300, 100);
		add(l2);
		
		l12.setBounds(500, 90, 300, 100);
		add(l12);
		
		l3.setBounds(200, 140, 300, 100);
		add(l3);
		
		l6.setBounds(500, 140, 300, 100);
		add(l6);
		
		l7.setBounds(500, 190, 300, 100);
		add(l7);
		
		l8.setBounds(500, 240, 300, 100);
		add(l8);
		
		l9.setBounds(500, 290, 300, 100);
		add(l9);
		
		l10.setBounds(500, 340, 500, 100);
		add(l10);
		
		l11.setBounds(500, 390, 300, 100);
		add(l11);
		
		l4.setBounds(200, 440, 300, 100);
		add(l4);
		
		l5.setBounds(200, 490, 300, 100);
		add(l5);
		
		b1.setBounds(370, 590, 100, 30);
		add(b1);
		
		b2.setBounds(490, 590, 100, 30);
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==b1) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 
		{
			System.exit(0);
		}
	}
	public static void main(String[] args) 
	{
		
		new Student_Clubs().setVisible(true);
	}

}
