import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Time_Table extends JFrame implements ActionListener	
{
	JLabel l1,l2,l3;
	JComboBox c1,c2;
	JButton b1,b2;
	public Time_Table()
	{
		super("TIME TABLE");
		l1 = new JLabel("Choose the following options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		l2 = new JLabel("Branch:");
		l2.setFont(new Font("Arial",Font.BOLD,21));
		
		l3 = new JLabel("Sem:");
		l3.setFont(new Font("Arial",Font.BOLD,21));
		
		
		String Branch[] = {"CSAI+CS(I)","IT+CS(II)"};
		c1 = new JComboBox(Branch);
		c1.setBackground(Color.WHITE);
		
		String Sem[] = {"1","2","3"};
		c2 = new JComboBox(Sem);
		c2.setBackground(Color.WHITE);
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,20));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(100, 20, 300, 100);
		add(l1);
		
		l2.setBounds(110, 120, 100, 100);
		add(l2);
		
		l3.setBounds(110, 180, 100, 100);
		add(l3);
		
		c1.setBounds(200, 155, 200, 25);
		add(c1);
		
		c2.setBounds(200, 215, 200, 25);
		add(c2);
		
		b1.setBounds(140, 330, 100, 30);
		add(b1);
		
		b2.setBounds(260, 330, 100, 30);
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(400,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		String ac = (String)c1.getSelectedItem();
		String bc = (String)c2.getSelectedItem();
		
		if(ae.getSource()==b1) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 
		{
			if(ac == "CSAI+CS(I)" & bc == "1") 
			{
				new csai1().setVisible(true);
			}
			else if(ac == "CSAI+CS(I)" & bc == "2")
			{
				new csai2().setVisible(true);
			}
			else if(ac == "CSAI+CS(I)" & bc == "3")
			{
				new csai3().setVisible(true);
			}
			else if(ac == "IT+CS(II)" & bc == "1") 
			{
				new it1().setVisible(true);
			}
			else if(ac == "IT+CS(II)" & bc == "2") 
			{
				new it2().setVisible(true);
			}
			else if(ac == "IT+CS(II)" & bc == "3") 
			{
				new it3().setVisible(true);
			}
		}
		
	}

	public static void main(String[] args) 
	{
		new Time_Table().setVisible(true);
	}

}

class csai1 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public csai1()
	{
		super("B.TECH CSAI + CS(I) SEMESTER-1 TIMETABLE");
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/AI SEM 1.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}

}

class csai2 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public csai2()
	{
		super("B.TECH CSAI + CS(I) SEMESTER-2 TIMETABLE");
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/AI SEM 2.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}
}

class csai3 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public csai3()
	{
		super("B.TECH CSAI + CS(I) SEMESTER-3 TIMETABLE");
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/AI SEM 3.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}
}

class it1 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public it1()
	{
		super("B.TECH IT + CS(II) SEMESTER-1 TIMETABLE");
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/IT SEM 1.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}

}

class it2 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public it2()
	{
		super("B.TECH IT + CS(II) SEMESTER-2 TIMETABLE");
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/IT SEM 2.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}
}

class it3 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1;
	public it3()
	{
		super("B.TECH IT + CS(II) SEMESTER-3 TIMETABLE");
		
		ImageIcon ic5 = new ImageIcon(this.getClass().getResource("/IT SEM 3.png"));
		Image i5 = ic5.getImage().getScaledInstance(900, 614, Image.SCALE_DEFAULT);
		ImageIcon icc5 = new ImageIcon(i5);
		l1 = new JLabel(icc5);
		
		b1 = new JButton("BACK");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(5, 30, 1000, 600);
		add(l1);
		
		b1.setBounds(450, 650, 100, 25);
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.pink);
		
		setLocation(170,10);
		setSize(1000,730);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		new Time_Table().setVisible(true);
		setVisible(false);
	}
}