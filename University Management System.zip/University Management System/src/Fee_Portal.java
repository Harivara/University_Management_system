import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Fee_Portal extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1,b2,b3,b4;
	public Fee_Portal()
	{
		super("FEE PAYMENT PORTAL");
		
		l1 = new JLabel("Select one of the options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		b1 = new JButton("Semester Fee Payment");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.white);
		b1.setForeground(Color.black);
		
		b2 = new JButton("Mess Fee Payment");
		b2.setFont(new Font("Raleway",Font.BOLD,20));
		b2.setBackground(Color.white);
		b2.setForeground(Color.black);
		
		b3 = new JButton("Back");
		b3.setFont(new Font("Raleway",Font.BOLD,16));
		b3.setBackground(Color.BLACK);
		b3.setForeground(Color.orange);
		
		b4 = new JButton("Exit");
		b4.setFont(new Font("Raleway",Font.BOLD,16));
		b4.setBackground(Color.BLACK);
		b4.setForeground(Color.red);
		
		setLayout(null);
		
		l1.setBounds(120, 20, 300, 100);
		add(l1);
		
		b1.setBounds(100, 150, 300, 40);
		add(b1);
		
		b2.setBounds(100, 220, 300, 40);
		add(b2);
		
		b3.setBounds(140, 330, 100, 30);
		add(b3);
		
		b4.setBounds(250, 330, 100, 30);
		add(b4);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(400,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==b1) 
		{
			new SemFee().setVisible(true);
		}
		else if(ae.getSource()==b2) 
		{
			new MessFee().setVisible(true);
		}
		else if(ae.getSource()==b3) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b4) 
		{
			System.exit(0);
		}
	}
	public static void main(String[] args) 
	{
		new Fee_Portal().setVisible(true);
		
	}

}


