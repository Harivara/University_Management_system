import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Sign_Up_Teacher extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;
	JRadioButton r1,r2,r3,r4,r5;
	JButton b;
	JComboBox c1,c2,c3;
	String e;
	public Sign_Up_Teacher() 
	{
		super("SIGN UP AS TEACHER");
		
		l1 = new JLabel("TEACHER SIGN UP");
		l1.setFont(new Font("Raleway",Font.BOLD,25));
		
		l2 = new JLabel("Name:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("Phone Number:");
		l3.setFont(new Font("Raleway",Font.BOLD,20));
		
		l4 = new JLabel("Date Of Birth:");
		l4.setFont(new Font("Raleway",Font.BOLD,20));
		
		l5 = new JLabel("Gender:");
		l5.setFont(new Font("Raleway",Font.BOLD,20));
		
		l6 = new JLabel("Degree:");
		l6.setFont(new Font("Raleway",Font.BOLD,20));
		
		l7 = new JLabel("Staff ID:");
		l7.setFont(new Font("Raleway",Font.BOLD,20));
		
		l8 = new JLabel("Vaccination Status:");
		l8.setFont(new Font("Raleway",Font.BOLD,20));
		
		l9 = new JLabel("Job Title:");
		l9.setFont(new Font("Raleway",Font.BOLD,20));
		
		l10 = new JLabel("Email Address:");
		l10.setFont(new Font("Raleway",Font.BOLD,20));
		
		l11 = new JLabel("State:");
		l11.setFont(new Font("Raleway",Font.BOLD,20));
		
		l12 = new JLabel("City:");
		l12.setFont(new Font("Raleway",Font.BOLD,20));
		
		l13 = new JLabel("Date");
		l13.setFont(new Font("Raleway",Font.BOLD,16));
		
		l14 = new JLabel("Month");
		l14.setFont(new Font("Raleway",Font.BOLD,16));
		
		l15 = new JLabel("Year");
		l15.setFont(new Font("Raleway",Font.BOLD,16));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf4 = new JTextField(20);
		tf4.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf5 = new JTextField(20);
		tf5.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf6 = new JTextField(20);
		tf6.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf7 = new JTextField(20);
		tf7.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf8 = new JTextField(20);
		tf8.setFont(new Font("Arial",Font.PLAIN,16));
		
		b = new JButton("Next");
		b.setFont(new Font("Raleway",Font.BOLD,18));
		b.setBackground(Color.black);
		b.setForeground(Color.white);
		
		r1 = new JRadioButton("Male");
		r1.setFont(new Font("Raleway",Font.BOLD,14));
		r1.setBackground(Color.WHITE);
		
		r2 = new JRadioButton("Female");
		r2.setFont(new Font("Raleway",Font.BOLD,14));
		r2.setBackground(Color.WHITE);
		
		r3 = new JRadioButton("Full");
		r3.setFont(new Font("Raleway",Font.BOLD,14));
		r3.setBackground(Color.WHITE);
		
		r4 = new JRadioButton("Partial");
		r4.setFont(new Font("Raleway",Font.BOLD,14));
		r4.setBackground(Color.WHITE);
		
		r5 = new JRadioButton("Not Vaccinated");
		r5.setFont(new Font("Raleway",Font.BOLD,14));
		r5.setBackground(Color.WHITE);
		
		String date[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","16","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
		c1 = new JComboBox(date);
		c1.setBackground(Color.WHITE);
		
		String Month[] = {"January","February","March","April","May","June","July","August","September","October","November","December"};
		c2 = new JComboBox(Month);
		c2.setBackground(Color.WHITE);
		
		String Year[] = {"1998","1999","2000","2001","2002","2003","2004"};
		c3 = new JComboBox(Year);
		c3.setBackground(Color.WHITE);
		
		setLayout(null);
		
		l1.setBounds(370,0, 250,150);		//teacher sign in
		add(l1);
		
		l2.setBounds(180, 100, 100, 100);		//name
		add(l2);
		
		l3.setBounds(180, 140, 150, 100);		//phone number
		add(l3);
		
		l4.setBounds(180, 180, 150, 100);		//date of birth
		add(l4);
		
		l5.setBounds(180, 220, 100, 100);		//gender
		add(l5);
		
		l6.setBounds(180, 260, 100, 100);		//degree
		add(l6);
		
		l7.setBounds(180, 300, 150, 100);		//staff id
		add(l7);
		
		l8.setBounds(180, 340, 200, 100);		//vaccination status
		add(l8);
		
		l9.setBounds(180, 380, 100, 100);		//job title
		add(l9);
		
		l10.setBounds(180, 420, 150, 100);		//email address
		add(l10);
		
		l11.setBounds(180, 460, 80, 100);		//state
		add(l11);
		
		l12.setBounds(180, 500, 100, 100);		//city
		add(l12);
		
		tf1.setBounds(430, 135, 350, 25);
		add(tf1);
		
		tf2.setBounds(430, 177, 350, 25);
		add(tf2);
		
		l13.setBounds(430, 190, 50, 75);		//date
		add(l13);
		
		c1.setBounds(475, 218, 50, 20);		//date
		add(c1);
		
		l14.setBounds(535, 190, 50, 75);		//month
		add(l14);
		
		c2.setBounds(590, 218, 86, 20);		//month
		add(c2);
		
		l15.setBounds(685, 190, 50, 75);		//year
		add(l15);
		
		c3.setBounds(725, 218, 60, 20);		//year
		add(c3);
		
		r1.setBounds(460, 255, 70, 20);		//male
		add(r1);
		
		r2.setBounds(650, 255, 80, 20);		//female
		add(r2);
		
		tf3.setBounds(430, 295, 350, 25);
		add(tf3);
		
		tf4.setBounds(430, 335, 350, 25);
		add(tf4);
		
		r3.setBounds(430, 380, 70, 20);		//fully
		add(r3);
		
		r4.setBounds(530, 380, 70, 20);		//partially
		add(r4);
		
		r5.setBounds(650, 380, 150, 20);		//not
		add(r5);
		
		tf5.setBounds(430, 415, 350, 25);
		add(tf5);
		
		tf6.setBounds(430, 455, 350, 25);
		add(tf6);
		
		tf7.setBounds(430, 495, 350, 25);
		add(tf7);
		
		tf8.setBounds(430, 535, 350, 25);
		add(tf8);
		
		b.setBounds(430, 590, 100, 30);
		add(b);
		
		b.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		String a = tf1.getText();		//name
		String b = tf2.getText();		//phone number
		
		String ac = (String)c1.getSelectedItem();		//date
		String bc = (String)c2.getSelectedItem();		//month
		String cc = (String)c3.getSelectedItem();		//year
		
		String c = null;
		if(r1.isSelected()) 
		{
			c = "Male";
		}
		else if(r2.isSelected())
		{
			c = "Female";
		}
		
		String d = tf3.getText();		//degree
		e = tf4.getText();		//staff id
		
		String f=null;
		if(r3.isSelected()) 
		{
			f = "Fully Vaccinated";
		}
		else if(r4.isSelected()) 
		{
			f = "Partially Vaccinated";
		}
		else if(r5.isSelected()) 
		{
			f = "Not Vaccinated";
		}
		
		String g = tf5.getText();		//job title
		String h = tf6.getText();		//email id
		String i = tf7.getText();		//state
		String j = tf8.getText();		//city
		
		try 
		{
			if(tf1.getText().equals("")||tf2.getText().equals("")||tf3.getText().equals("")||tf4.getText().equals("")||tf5.getText().equals("")) 
			{
				JOptionPane.showMessageDialog(null, "Fill all the required Data");
			}
			else 
			{
				conn c1 = new conn();
				String q = "INSERT INTO teacher1 VALUES('"+a+"','"+b+"','"+ac+"','"+bc+"','"+cc+"','"+c+"','"+d+"','"+f+"','"+g+"','"+h+"','"+i+"','"+j+"','"+e+"')";
				c1.s.executeUpdate(q);
				
				new Sign_Up_Teacher_2().setVisible(true);
				setVisible(false);
			}
		}
		catch (Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
	public static void main(String[] args)
	{
		new Sign_Up_Teacher().setVisible(true);
		
	}

}

class Sign_Up_Teacher_2 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2;
	JTextField tf1,tf2;
	public Sign_Up_Teacher_2()
	{
		l1 = new JLabel("Staff ID:");
		l1.setFont(new Font("Ralewat",Font.BOLD,18));
				
		l2 = new JLabel("Set Password:");
		l2.setFont(new Font("Raleway",Font.BOLD,18));
		
		l3 = new JLabel("(Min 3 Characters)");
		l3.setFont(new Font("Raleway",Font.BOLD,16));
		
		l4 = new JLabel("TEACHER SIGN UP");
		l4.setFont(new Font("Raleway",Font.BOLD,20));
		
		l5 = new JLabel("Page. 2");
		l5.setFont(new Font("Raleway",Font.PLAIN,18));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		
		setLayout(null);
		
		
		l4.setBounds(150, 20, 200, 100);		//teacher sign up
		add(l4);
		
		l5.setBounds(210, 50, 100, 100);		//page 2
		add(l5);
		
		l1.setBounds(80, 150, 100, 100);		//staff id
		add(l1);
		
		l2.setBounds(80, 210, 200, 100);		//set password
		add(l2);
		
		l3.setBounds(80, 230, 200, 100);		//min 3 char
		add(l3);
		
		tf1.setBounds(250, 185, 150, 25);
		add(tf1);
		
		tf2.setBounds(250, 250, 150, 25);
		add(tf2);
		
		b1.setBounds(100, 350, 100, 30);		//back
		add(b1);
		
		b2.setBounds(275, 350, 100, 30);		//next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(425,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		Sign_Up_Teacher t1  = new Sign_Up_Teacher();
		
		t1.setVisible(false);
		
		String a = tf1.getText();
		String b = tf2.getText();
		
		try 
		{
			if(ae.getSource()==b2) 		//next
			{
				if(tf1.getText().equals("") || tf2.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
						
					ResultSet rs  = c1.s.executeQuery("Select * from teacher1 where STAFF_ID = '"+a+"';");
						
					if(rs.next()) 
					{
						String q = "INSERT INTO login(user_id,password) VALUES('"+a+"','"+b+"')";
							
						c1.s.executeUpdate(q);
							
							
						JOptionPane.showMessageDialog(null, "Login ID: " + a + "\n Password: " + b);
							
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Enter the same Staff Id as in the previous page");
					}
						
						
				}
				
			}
			else if(ae.getSource()==b1) 		//back
			{
				new Sign_Up_Teacher().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
	

}



