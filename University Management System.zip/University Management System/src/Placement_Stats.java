import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Placement_Stats extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton b1,b2;
	JComboBox c1;
	public Placement_Stats() 
	{
		super("PLACEMENT STATS");
		
		l1 = new JLabel("Select one of the options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		l2 = new JLabel("Year:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		String Year[] = {"2020-21","2019-20","2018-19"};
		c1 = new JComboBox(Year);
		c1.setBackground(Color.WHITE);
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,16));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,16));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		
		setLayout(null);
		
		l1.setBounds(120, 20, 300, 100);
		add(l1);
		
		l2.setBounds(120, 100, 100, 100);
		add(l2);
		
		c1.setBounds(180, 135, 190, 30);
		add(c1);
		
		b1.setBounds(130, 250, 100, 30);
		add(b1);
		
		b2.setBounds(250, 250, 100, 30);
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,150);
		setSize(500,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void actionPerformed(ActionEvent ae) 
	{
		String ac = (String)c1.getSelectedItem();
		
		if(ae.getSource()==b1) 
		{
			new Contents().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 
		{
			if(ac == "2020-21") 
			{
				new ps2021().setVisible(true);
			}
			else if(ac =="2019-20") 
			{
				new ps2020().setVisible(true);
			}
			else if(ac == "2018-19") 
			{
				new ps2019().setVisible(true);
			}			
		}
	}
	public static void main(String[] args) 
	{
		new Placement_Stats().setVisible(true);

	}

}

class ps2021 extends JFrame
{
	JLabel l1,l2,l3,l4,l5;
	public ps2021()
	{
		super("PLACEMENT STATS");
		l1 = new JLabel("Placement Statistics(B.tech) 2020-21");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		ImageIcon ic1 = new ImageIcon(this.getClass().getResource("/ps2021_1.png"));
		Image i1 = ic1.getImage().getScaledInstance(200, 120, Image.SCALE_DEFAULT);
		ImageIcon icc1 = new ImageIcon(i1);
		l2 = new JLabel(icc1);
		
		ImageIcon ic2 = new ImageIcon(this.getClass().getResource("/ps2021_2.png"));
		Image i2 = ic2.getImage().getScaledInstance(300, 160, Image.SCALE_DEFAULT);
		ImageIcon icc2 = new ImageIcon(i2);
		l3 = new JLabel(icc2);
		
		ImageIcon ic3 = new ImageIcon(this.getClass().getResource("/ps2021_3.png"));
		Image i3 = ic3.getImage().getScaledInstance(250, 230, Image.SCALE_DEFAULT);
		ImageIcon icc3 = new ImageIcon(i3);
		l4 = new JLabel(icc3);
		
		ImageIcon ic4 = new ImageIcon(this.getClass().getResource("/ps2021_4.png"));
		Image i4 = ic4.getImage().getScaledInstance(200, 130, Image.SCALE_DEFAULT);
		ImageIcon icc4 = new ImageIcon(i4);
		l5 = new JLabel(icc4);
		
		setLayout(null);
		
		l1.setBounds(190, 30, 600, 100);
		add(l1);
		
		l2.setBounds(100, 110, 300, 300);
		add(l2);
		
		l3.setBounds(500,20, 300, 500);
		add(l3);
		
		l4.setBounds(150, 200, 300, 600);
		add(l4);
		
		l5.setBounds(550, 200, 300, 500);
		add(l5);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		
	}
}

class ps2020 extends JFrame
{
	JLabel l1,l2,l3,l4,l5;
	public ps2020()
	{
		super("PLACEMENT STATS");
		l1 = new JLabel("Placement Statistics(B.tech) 2019-20");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		ImageIcon ic1 = new ImageIcon(this.getClass().getResource("/ps2020_1.png"));
		Image i1 = ic1.getImage().getScaledInstance(250, 180, Image.SCALE_DEFAULT);
		ImageIcon icc1 = new ImageIcon(i1);
		l2 = new JLabel(icc1);
		
		ImageIcon ic2 = new ImageIcon(this.getClass().getResource("/ps2020_2.png"));
		Image i2 = ic2.getImage().getScaledInstance(330, 200, Image.SCALE_DEFAULT);
		ImageIcon icc2 = new ImageIcon(i2);
		l3 = new JLabel(icc2);
		
		ImageIcon ic3 = new ImageIcon(this.getClass().getResource("/ps2020_3.png"));
		Image i3 = ic3.getImage().getScaledInstance(250, 280, Image.SCALE_DEFAULT);
		ImageIcon icc3 = new ImageIcon(i3);
		l4 = new JLabel(icc3);
		
		ImageIcon ic4 = new ImageIcon(this.getClass().getResource("/ps2020_4.png"));
		Image i4 = ic4.getImage().getScaledInstance(200, 130, Image.SCALE_DEFAULT);
		ImageIcon icc4 = new ImageIcon(i4);
		l5 = new JLabel(icc4);
		
		setLayout(null);
		
		l1.setBounds(190, 30, 600, 100);
		add(l1);
		
		l2.setBounds(100, 110, 300, 300);
		add(l2);
		
		l3.setBounds(500,20, 300, 500);
		add(l3);
		
		l4.setBounds(150, 200, 300, 600);
		add(l4);
		
		l5.setBounds(550, 250, 300, 500);
		add(l5);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		
	}
}

class ps2019 extends JFrame
{
	JLabel l1,l2,l3,l4;
	public ps2019()
	{
		super("PLACEMENT STATS");
		l1 = new JLabel("Placement Statistics(B.tech) 2018-19");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		ImageIcon ic1 = new ImageIcon(this.getClass().getResource("/ps2019_1.png"));
		Image i1 = ic1.getImage().getScaledInstance(260, 150, Image.SCALE_DEFAULT);
		ImageIcon icc1 = new ImageIcon(i1);
		l2 = new JLabel(icc1);
		
		ImageIcon ic2 = new ImageIcon(this.getClass().getResource("/ps2019_2.png"));
		Image i2 = ic2.getImage().getScaledInstance(300, 260, Image.SCALE_DEFAULT);
		ImageIcon icc2 = new ImageIcon(i2);
		l3 = new JLabel(icc2);
		
		ImageIcon ic3 = new ImageIcon(this.getClass().getResource("/ps2019_3.png"));
		Image i3 = ic3.getImage().getScaledInstance(320, 220, Image.SCALE_DEFAULT);
		ImageIcon icc3 = new ImageIcon(i3);
		l4 = new JLabel(icc3);
		
		setLayout(null);
		
		l1.setBounds(190, 30, 600, 100);
		add(l1);
		
		l2.setBounds(100, 110, 300, 300);
		add(l2);
		
		l3.setBounds(500,20, 300, 500);
		add(l3);
		
		l4.setBounds(300, 200, 300, 600);
		add(l4);
		
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		
	}
}
