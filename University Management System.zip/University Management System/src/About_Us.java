import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class About_Us extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14;
	JButton b1;
	public About_Us() 
	{
		super("ABOUT US");
		
		l1 = new JLabel("ABOUT US");
		l1.setFont(new Font("Verdana",Font.BOLD,30));
		
		l2 = new JLabel("Indian Institute of Information Technology, Lucknow (IIIT Lucknow) is one of the 20 IIITs");
		l2.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l3 = new JLabel("being set up by the Central Government in Public Private Partnership (PPP) mode. IIIT");
		l3.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l4 = new JLabel("Lucknow admitted its first batch of B. Tech. in Information Technology with an intake of ");
		l4.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l5 = new JLabel("50 students w.e.f. the academic session 2015-16. It currently offers all the amenities ,");
		l5.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l6 = new JLabel("academic and non-academic to its students that can help them flourish and serve the nation");
		l6.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l7 = new JLabel("with all their apprehension in the various fields of technology. The admission is made through ");
		l7.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l8 = new JLabel("central counselling of candidates who qualify in JEE (Mains).");
		l8.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l9 = new JLabel("The Institute is being set up with the financial contributions of MHRD, Govt. of India, Govt.");
		l9.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l10 = new JLabel("of Uttar Pradesh, and U. P. Electronics Corporation Ltd. as industry partners. The mission of ");
		l10.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l11 = new JLabel("IIIT Lucknow is to be a unique and world class nucleating �Apex Center of Excellence� in the ");
		l11.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l12 = new JLabel("area of Information Technology so as to enhance India�s Technological strength in Information ");
		l12.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l13 = new JLabel("Technology . IIIT seeks to derive its strength from a linkage with sound Indian traditions of ");
		l13.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l14 = new JLabel("centuries past, and sets out to create knowledge-based resources in regional languages.");
		l14.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,20));
		b1.setBackground(Color.white);
		b1.setForeground(Color.orange);
		
		
		setLayout(null);
		
		l1.setBounds(400, 30, 200, 100);
		add(l1);
		
		l2.setBounds(100, 110, 810, 100);
		add(l2);
		
		l3.setBounds(100, 140, 830, 100);
		add(l3);
		
		l4.setBounds(100, 170, 830, 100);
		add(l4);
		
		l5.setBounds(100, 200, 830, 100);
		add(l5);
		
		l6.setBounds(100, 230, 830, 100);
		add(l6);
		
		l7.setBounds(100, 260, 830, 100);
		add(l7);
		
		l8.setBounds(100, 290, 830, 100);
		add(l8);
		
		l9.setBounds(100, 350, 830, 100);
		add(l9);
		
		l10.setBounds(100, 380, 830, 100);
		add(l10);
		
		l11.setBounds(100, 410, 830, 100);
		add(l11);
		
		l12.setBounds(100, 440, 840, 100);
		add(l12);
		
		l13.setBounds(100, 470, 840, 100);
		add(l13);
		
		l14.setBounds(100, 500, 840, 100);
		add(l14);
		
		b1.setBounds(50, 30, 100, 25);		//back
		add(b1);
		
		b1.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void actionPerformed(ActionEvent ae) 
	{
		new Contents().setVisible(true);
		setVisible(false);
	}

	public static void main(String[] args) {
		new About_Us().setVisible(true);

	}

}
