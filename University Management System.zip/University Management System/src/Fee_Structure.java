import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Fee_Structure extends JFrame implements ActionListener
{
	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","PAYMENT FOR","1st SEM","2nd SEM","3rd SEM","4th SEM","5th SEM","6th SEM","7th SEM","8th SEM"};
	String y [][] = new String[40][20] ;
	int i=0,j=0;
	public Fee_Structure() 
	{
		super("FEE STRUCTURE");
		
		setLocation(150,80);
		setSize(1100,500);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select * from fee;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = rs.getString("S_No");
				y[i][j++] = rs.getString("Payment_For");
				y[i][j++] = rs.getString("1st_Sem");
				y[i][j++] = rs.getString("2nd_Sem");
				y[i][j++] = rs.getString("3rd_Sem");
				y[i][j++] = rs.getString("4th_Sem");
				y[i][j++] = rs.getString("5th_Sem");
				y[i][j++] = rs.getString("6th_Sem");
				y[i][j++] = rs.getString("7th_Sem");
				y[i][j++] = rs.getString("8th_Sem");
				i++;
				j=0;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.white);
		
		
		setVisible(true);
	}
		
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}catch(Exception e) 
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args) 
	{
		new Fee_Structure().setVisible(true);
	}

}
