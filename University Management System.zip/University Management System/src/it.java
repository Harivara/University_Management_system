import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

class it extends JFrame
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
	public it() 
	{
		super("ACADEMIC PROGRAMS");
		
		l1 = new JLabel("B.Tech(IT)");
		l1.setFont(new Font("Verdana",Font.BOLD,28));
		
		l2 = new JLabel("Admissions to the four year B.Tech. Program in IT branch of ");
		l2.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l3 = new JLabel("the Institute is made through The Joint Seat Allocation Authority ");
		l3.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l4 = new JLabel("2020 (JoSAA-2020)  and Central Seat Allocation Board 2020  ");
		l4.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l5 = new JLabel("(CSAB-2021). Based upon the merit in JEE (Mains).");
		l5.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l6 = new JLabel("The Institute is open to all races, creeds and classes including ");
		l6.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l7 = new JLabel("persons of either sex (including transgender).As Central Education ");
		l7.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l8 = new JLabel("Institution IIIT follows the Central Educational Institutions ");
		l8.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		l9 = new JLabel("(Reservation in Admission) Act, 2006.");
		l9.setFont(new Font("Baskerville",Font.PLAIN,20));
		
		setLayout(null);
		
		l1.setBounds(250, 30, 200, 100);
		add(l1);
		
		l2.setBounds(70, 120, 550, 100);
		add(l2);
		
		l3.setBounds(70, 150, 585, 100);
		add(l3);
		
		l4.setBounds(70, 180, 585, 100);
		add(l4);
		
		l5.setBounds(70, 210, 585, 100);
		add(l5);
		
		l6.setBounds(70, 270, 585, 100);
		add(l6);
		
		l7.setBounds(70, 300, 600, 100);
		add(l7);
		
		l8.setBounds(70, 330, 600, 100);
		add(l8);
		
		l9.setBounds(70, 360, 600, 100);
		add(l9);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(350,90);
		setSize(700,600);
		setVisible(true);
	}
	public static void main(String[] args) {
		new it().setVisible(true);

	}
}