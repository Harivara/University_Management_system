import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Mess_Menu extends JFrame implements ActionListener
{
	JTable t1;
	JButton b1,b2;
	String x[] = {"Timings and Day","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
	String y [][] = new String[16][9] ;
	int i=0,j=0;
	public Mess_Menu() 
	{
		super("MESS MENU");
		
		setLocation(150,170);
		setSize(1100,343);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select * from mess;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = rs.getString("TimingsAndDay");
				y[i][j++] = rs.getString("Monday");
				y[i][j++] = rs.getString("Tuesday");
				y[i][j++] = rs.getString("Wednesday");
				y[i][j++] = rs.getString("Thursday");
				y[i][j++] = rs.getString("Friday");
				y[i][j++] = rs.getString("Saturday");
				y[i][j++] = rs.getString("Sunday");
				i++;
				j=0;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.white);
		
		
		setVisible(true);
		
	
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}catch(Exception e) 
		{
			System.out.println(e);
		}

	}

	public static void main(String[] args) 
	{
		new Mess_Menu().setVisible(true);

	}

}
