import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Contents extends JFrame implements ActionListener
{
	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;
	JLabel l1,l2;
	
	public Contents() 
	{
		super("HOME");
		
		b1 = new JButton("VIEW DETAILS");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("FEE PAYMENT PORTAL");
		b2.setFont(new Font("Raleway",Font.BOLD,14));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.orange);
		
		b3 = new JButton("TIME TABLE");
		b3.setFont(new Font("Raleway",Font.BOLD,14));
		b3.setBackground(Color.BLACK);
		b3.setForeground(Color.orange);
		
		b4 = new JButton("LIST OF HOLIDAYS");
		b4.setFont(new Font("Raleway",Font.BOLD,14));
		b4.setBackground(Color.BLACK);
		b4.setForeground(Color.orange);
		
		b5 = new JButton("VACCINATION STATUS");
		b5.setFont(new Font("Raleway",Font.BOLD,14));
		b5.setBackground(Color.BLACK);
		b5.setForeground(Color.orange);
		
		b6 = new JButton("FEE STRUCTURE");
		b6.setFont(new Font("Raleway",Font.BOLD,14));
		b6.setBackground(Color.BLACK);
		b6.setForeground(Color.orange);
		
		b7 = new JButton("MESS MENU");
		b7.setFont(new Font("Raleway",Font.BOLD,14));
		b7.setBackground(Color.BLACK);
		b7.setForeground(Color.orange);
		
		b8 = new JButton("STUDENT CLUBS");
		b8.setFont(new Font("Raleway",Font.BOLD,14));
		b8.setBackground(Color.BLACK);
		b8.setForeground(Color.orange);
		
		b9 = new JButton("PLACEMENT STATS");
		b9.setFont(new Font("Raleway",Font.BOLD,14));
		b9.setBackground(Color.BLACK);
		b9.setForeground(Color.orange);
		
		b10 = new JButton("ACADEMIC PROGRAMS");
		b10.setFont(new Font("Raleway",Font.BOLD,14));
		b10.setBackground(Color.BLACK);
		b10.setForeground(Color.orange);
		
		b11 = new JButton("ABOUT US");
		b11.setFont(new Font("Raleway",Font.BOLD,14));
		b11.setBackground(Color.BLACK);
		b11.setForeground(Color.orange);
		
		b12 = new JButton("EXIT");
		b12.setFont(new Font("Raleway",Font.BOLD,14));
		b12.setBackground(Color.BLACK);
		b12.setForeground(Color.RED);
		
		l1 = new JLabel("HOME PAGE");
		l1.setFont(new Font("Raleway",Font.BOLD,26));
		
		ImageIcon ic1 = new ImageIcon(this.getClass().getResource("/Logo.png"));
		Image i1 = ic1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
		ImageIcon icc1 = new ImageIcon(i1);
		l2 = new JLabel(icc1);
		
		setLayout(null);
		
		l1.setBounds(400, 90, 200, 100);
		add(l1);
		
		l2.setBounds(430, 10, 100, 100);
		add(l2);
		
		b1.setBounds(200, 200, 200, 50);
		add(b1);
		
		b2.setBounds(200, 270, 200, 50);
		add(b2);
		
		b3.setBounds(200, 340, 200, 50);
		add(b3);
		
		b4.setBounds(200, 410, 200, 50);
		add(b4);
		
		b5.setBounds(200, 480, 200, 50);
		add(b5);
		
		b6.setBounds(200, 550, 200, 50);
		add(b6);
		
		b7.setBounds(550, 200, 200, 50);
		add(b7);
		
		b8.setBounds(550, 270, 200, 50);
		add(b8);
		
		b9.setBounds(550, 340, 200, 50);
		add(b9);
		
		b10.setBounds(550, 410, 200, 50);
		add(b10);
		
		b11.setBounds(550, 480, 200, 50);		//about us
		add(b11);
		
		b12.setBounds(550, 550, 200, 50);
		add(b12);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		b9.addActionListener(this);
		b10.addActionListener(this);
		b11.addActionListener(this);
		b12.addActionListener(this);

				
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==b1) 
		{
			new view_details().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 
		{
			new Fee_Portal().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b3) 
		{
			new Time_Table().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b4) 
		{
			new Holiday().setVisible(true);
		}
		else if(ae.getSource()==b5) 
		{
			new Vacc_Status().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b6) 
		{
			new Fee_Structure().setVisible(true);
		}
		else if(ae.getSource()==b7) 
		{
			new Mess_Menu().setVisible(true);
		}
		else if(ae.getSource()==b8) 
		{
			new Student_Clubs().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b9) 
		{
			new Placement_Stats().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b10) 
		{
			new Aca_Prog().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b11) 
		{
			new About_Us().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b12) 
		{
			System.exit(0);
		}

	}
	public static void main(String[] args) {
		new Contents().setVisible(true);

	}

}
