import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class SemFee extends JFrame implements ActionListener
{
	String ac;
	JLabel l1,l2;
	JButton b1,b2,b3;
	JComboBox c1;
	public SemFee() 
	{
		super("SEMESTER FEE PAYMENT");
		
		l1 = new JLabel("Select one of the options");
		l1.setFont(new Font("Arial",Font.BOLD,22));
		
		l2 = new JLabel("Semester:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		String Sem[] = {"1","2","3","4","5","6","7","8"};
		c1 = new JComboBox(Sem);
		c1.setBackground(Color.WHITE);
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,16));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.orange);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,16));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		
		b3 = new JButton("View Payment Details");
		b3.setFont(new Font("Raleway",Font.BOLD,16));
		b3.setBackground(Color.white);
		b3.setForeground(Color.RED);
		
		setLayout(null);
		
		l1.setBounds(120, 20, 300, 100);
		add(l1);
		
		l2.setBounds(120, 100, 100, 100);
		add(l2);
		
		c1.setBounds(250, 135, 90, 30);
		add(c1);
		
		b1.setBounds(130, 230, 100, 30);
		add(b1);
		
		b2.setBounds(250, 230, 100, 30);
		add(b2);
		
		b3.setBounds(130, 300, 220, 30);
		add(b3);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,150);
		setSize(500,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void actionPerformed(ActionEvent ae) 
	{
		ac = (String)c1.getSelectedItem();
		
		if(ae.getSource()==b1) 		//back
		{
			new Fee_Portal().setVisible(true);
			setVisible(false);
		}
		else if(ae.getSource()==b2) 		//next
		{
			
			if(ac == "1") 
			{
				new sem1().setVisible(true);
				setVisible(false);
			}
			else if(ac == "2") 
			{
				new sem2().setVisible(true);
				setVisible(false);
			}
			else if(ac == "3" || ac == "5" || ac == "7") 
			{
				new sem357().setVisible(true);
				setVisible(false);
			}
			else if(ac == "4" || ac=="6" || ac =="8") 
			{
				new sem468().setVisible(true);
				setVisible(false);
			};
		}
		else if (ae.getSource()==b3) 		//view payment details
		{
			new sempaymentdetails().setVisible(true);
		}
	}

	public static void main(String[] args) 
	{
		new SemFee().setVisible(true);

	}

}

class sempaymentdetails extends JFrame implements ActionListener
{
	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","ROLL NUMBER","NAME","PHONE NUMBER","DATE","MONTH","YEAR","AMOUNT","CITY","STATE"};
	String y [][] = new String[100][20] ;
	int i=0,j=0,k=1;
	public sempaymentdetails() 
	{
		super("FEE STRUCTURE");
		
		setLocation(150,80);
		setSize(1100,500);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select student1.ROLL_NO,NAME,student1.PHONE_NO,DATE,MONTH,YEAR,AMOUNT,CITY,STATE from student1,semfee where student1.ROLL_NO = semfee.ROLL_NO and student1.PHONE_NO = semfee.phone_no order by student1.ROLL_NO;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = Integer.toString(k);
				y[i][j++] = rs.getString("student1.ROLL_NO");
				y[i][j++] = rs.getString("NAME");
				y[i][j++] = rs.getString("student1.PHONE_NO");
				y[i][j++] = rs.getString("DATE");
				y[i][j++] = rs.getString("MONTH");
				y[i][j++] = rs.getString("YEAR");
				y[i][j++] = rs.getString("AMOUNT");
				y[i][j++] = rs.getString("CITY");
				y[i][j++] = rs.getString("STATE");
				i++;
				j=0;
				k++;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.white);
		
		
		setVisible(true);
	}
		
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}catch(Exception e) 
		{
			System.out.println(e);
		}
	}
}

class sem1 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2;
	JTextField tf1,tf2,tf3;
	
	public sem1()
	{
		super("SEMESTER FEE PAYMENT");
		
		
		l1 = new JLabel("Roll Number:");
		l1.setFont(new Font("Ralewat",Font.BOLD,20));
				
		l2 = new JLabel("Amount:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("TOTAL FEE:");
		l3.setFont(new Font("Raleway",Font.BOLD,22));
		
		l4 = new JLabel("134000 Rupees");
		l4.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l5 = new JLabel("Phone Number:");
		l5.setFont(new Font("Ralewat",Font.BOLD,20));
		
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		
		setLayout(null);
		
		
		l3.setBounds(110, 50, 600, 80);         //total fee
		add(l3);
		
		l4.setBounds(260, 40, 800, 100);        //amount to be paid
		add(l4);
		
		l1.setBounds(80, 120, 300, 100);        //roll number
		add(l1);
		
		l5.setBounds(80, 170, 300, 100);        //phone number
		add(l5);
		
		l2.setBounds(80, 220, 200, 100);        //amount
		add(l2);
		
		tf1.setBounds(250, 160, 150, 25);       //textfield for roll number
		add(tf1);
		
		tf2.setBounds(250, 207, 150, 25);       //textfield for phone number
		add(tf2);
		
		tf3.setBounds(250, 258, 150, 25);       //textfield for amount
		add(tf3);
		
		b1.setBounds(100, 350, 100, 30);        //back
		add(b1);
		
		b2.setBounds(275, 350, 100, 30);        //next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();               //Roll Number
		String b = "SEM 1: "  +  tf3.getText(); //Amount
		String c = tf2.getText();               //Phone Number
		
		try 
		{
			if(ae.getSource()==b2)  //next
			{
				if(tf1.getText().equals("") || tf2.getText().equals("") || tf3.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
					
					ResultSet rs = c1.s.executeQuery("select student1.PHONE_NO,semfee.phone_no from student1,semfee where student1.PHONE_NO = '"+c+"' and student1.ROLL_NO = '"+a+"' ;");
					
					if(rs.next()) 
					{
						String q = "INSERT INTO semfee VALUES('"+a+"','"+b+"' , '"+c+"');";
						
						c1.s.executeUpdate(q);
						
						
						JOptionPane.showMessageDialog(null, "Roll Number: " + a + "\n Amount Paid: " + b);
						
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
					}
					
					
					
				}
			}
			else if(ae.getSource()==b1)  //back
			{
				new SemFee().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
}

class sem2 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2;
	JTextField tf1,tf2,tf3;
	
	public sem2()
	{
		super("SEMESTER FEE PAYMENT");
		
		
		l1 = new JLabel("Roll Number:");
		l1.setFont(new Font("Ralewat",Font.BOLD,20));
				
		l2 = new JLabel("Amount:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("TOTAL FEE:");
		l3.setFont(new Font("Raleway",Font.BOLD,22));
		
		l4 = new JLabel("111700 Rupees");
		l4.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l5 = new JLabel("Phone Number:");
		l5.setFont(new Font("Ralewat",Font.BOLD,20));
		
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		
		setLayout(null);
		
		
		l3.setBounds(110, 50, 600, 80);         //total fee
		add(l3);
		
		l4.setBounds(260, 40, 800, 100);        //amount to be paid
		add(l4);
		
		l1.setBounds(80, 120, 300, 100);        //roll number
		add(l1);
		
		l5.setBounds(80, 170, 300, 100);        //phone number
		add(l5);
		
		l2.setBounds(80, 220, 200, 100);        //amount
		add(l2);
		
		tf1.setBounds(250, 160, 150, 25);       //textfield for roll number
		add(tf1);
		
		tf2.setBounds(250, 207, 150, 25);       //textfield for phone number
		add(tf2);
		
		tf3.setBounds(250, 258, 150, 25);       //textfield for amount
		add(tf3);
		
		b1.setBounds(100, 350, 100, 30);        //back
		add(b1);
		
		b2.setBounds(275, 350, 100, 30);        //next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();               //Roll Number
		String b = "SEM 2: "  +  tf3.getText(); //Amount
		String c = tf2.getText();               //Phone Number
		
		try 
		{
			if(ae.getSource()==b2)  //next
			{
				if(tf1.getText().equals("") || tf2.getText().equals("") || tf3.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
					
					ResultSet rs = c1.s.executeQuery("select student1.PHONE_NO , semfee.ROLL_NO , AMOUNT from student1,semfee where student1.PHONE_NO = '"+c+"' and student1.ROLL_NO = '"+a+"' ;");
					
					if(rs.next()) 
					{
						String q = "INSERT INTO semfee VALUES('"+a+"','"+b+"' , '"+c+"');";
						
						c1.s.executeUpdate(q);
						
						
						JOptionPane.showMessageDialog(null, "Roll Number: " + a + "\n Amount Paid: " + b);
						
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
					}
					
					
					
				}
			}
			else if(ae.getSource()==b1)  //back
			{
				new SemFee().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
}


class sem357 extends JFrame implements ActionListener
{
	SemFee sf = new SemFee();
	String x = sf.ac;
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2;
	JTextField tf1,tf2,tf3;
	
	public sem357()
	{
		super("SEMESTER FEE PAYMENT");
		
		sf.setVisible(false);
		
		l1 = new JLabel("Roll Number:");
		l1.setFont(new Font("Ralewat",Font.BOLD,20));
				
		l2 = new JLabel("Amount:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("TOTAL FEE:");
		l3.setFont(new Font("Raleway",Font.BOLD,22));
		
		l4 = new JLabel("136500 Rupees");
		l4.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l5 = new JLabel("Phone Number:");
		l5.setFont(new Font("Ralewat",Font.BOLD,20));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		
		setLayout(null);
		
		
		l3.setBounds(110, 50, 600, 80);         //total fee
		add(l3);
		
		l4.setBounds(260, 40, 800, 100);        //amount to be paid
		add(l4);
		
		l1.setBounds(80, 120, 300, 100);        //roll number
		add(l1);
		
		l5.setBounds(80, 170, 300, 100);        //phone number
		add(l5);
		
		l2.setBounds(80, 220, 200, 100);        //amount
		add(l2);
		
		tf1.setBounds(250, 160, 150, 25);       //textfield for roll number
		add(tf1);
		
		tf2.setBounds(250, 207, 150, 25);       //textfield for phone number
		add(tf2);
		
		tf3.setBounds(250, 258, 150, 25);       //textfield for amount
		add(tf3);
		
		b1.setBounds(100, 350, 100, 30);        //back
		add(b1);
		
		b2.setBounds(275, 350, 100, 30);        //next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();
		String b = "SEM " +  this.x  +": "  +  tf3.getText();
		String c = tf2.getText();
		
		try 
		{
			if(ae.getSource()==b2)   //next
			{
				if(tf1.getText().equals("") || tf2.getText().equals("") || tf3.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
					
					ResultSet rs  = c1.s.executeQuery("select student1.PHONE_NO , semfee.ROLL_NO , AMOUNT from student1,semfee where student1.PHONE_NO = '"+c+"' and student1.ROLL_NO = '"+a+"' ;");
					
					if(rs.next()) 
					{
						String q = "INSERT INTO semfee VALUES('"+a+"','"+b+"' , '"+c+"')";
						
						c1.s.executeUpdate(q);
						
						
						JOptionPane.showMessageDialog(null, "Roll Number: " + a + "\n Amount Paid: " + b);
						
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
					}
					
				}
			}
			else if(ae.getSource()==b1)  //back
			{
				new SemFee().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
	
}

class sem468 extends JFrame implements ActionListener
{
	SemFee sf = new SemFee();
	String x = sf.ac;
	JLabel l1,l2,l3,l4,l5;
	JButton b1,b2;
	JTextField tf1,tf2,tf3;
	
	public sem468()
	{
		super("SEMESTER FEE PAYMENT");
		
		sf.setVisible(false);
		
		l1 = new JLabel("Roll Number:");
		l1.setFont(new Font("Ralewat",Font.BOLD,20));
				
		l2 = new JLabel("Amount:");
		l2.setFont(new Font("Raleway",Font.BOLD,20));
		
		l3 = new JLabel("TOTAL FEE:");
		l3.setFont(new Font("Raleway",Font.BOLD,22));
		
		l4 = new JLabel("132700 Rupees");
		l4.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l5 = new JLabel("Phone Number:");
		l5.setFont(new Font("Ralewat",Font.BOLD,20));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,16));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,16));
		
		b1 = new JButton("Back");
		b1.setFont(new Font("Raleway",Font.BOLD,18));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		
		b2 = new JButton("Next");
		b2.setFont(new Font("Raleway",Font.BOLD,18));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		
		
		setLayout(null);
		
		
		l3.setBounds(110, 50, 600, 80);         //total fee
		add(l3);
		
		l4.setBounds(260, 40, 800, 100);        //amount to be paid
		add(l4);
		
		l1.setBounds(80, 120, 300, 100);        //roll number
		add(l1);
		
		l5.setBounds(80, 170, 300, 100);        //phone number
		add(l5);
		
		l2.setBounds(80, 220, 200, 100);        //amount
		add(l2);
		
		tf1.setBounds(250, 160, 150, 25);       //textfield for roll number
		add(tf1);
		
		tf2.setBounds(250, 207, 150, 25);       //textfield for phone number
		add(tf2);
		
		tf3.setBounds(250, 258, 150, 25);       //textfield for amount
		add(tf3);
		
		b1.setBounds(100, 350, 100, 30);        //back
		add(b1);
		
		b2.setBounds(275, 350, 100, 30);        //next
		add(b2);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(410,100);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();
		String b = "SEM " +  x  +": "  +  tf3.getText();
		String c = tf2.getText();
		
		try 
		{
			if(ae.getSource()==b2)   //next
			{
				if(tf1.getText().equals("") || tf2.getText().equals("") || tf3.getText().equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fill all the required data");
				}
				else 
				{
					conn c1 = new conn();
					
					ResultSet rs  = c1.s.executeQuery("select student1.PHONE_NO , semfee.ROLL_NO , AMOUNT from student1,semfee where student1.PHONE_NO = '"+c+"' and student1.ROLL_NO = '"+a+"' ;");
					
					if(rs.next()) 
					{
						String q = "INSERT INTO semfee VALUES('"+a+"','"+b+"' , '"+c+"')";
						
						c1.s.executeUpdate(q);
						
						
						JOptionPane.showMessageDialog(null, "Roll Number: " + a + "\n Amount Paid: " + b);
						
						new Contents().setVisible(true);
						setVisible(false);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Incorrect Roll Number or Phone Number");
					}
					
				}
			}
			else if(ae.getSource()==b1)  //back
			{
				new SemFee().setVisible(true);
				setVisible(false);
			}
		}
		catch(Exception ex) 
		{
			System.err.println("error" + ex);
		}
		
	}
}
