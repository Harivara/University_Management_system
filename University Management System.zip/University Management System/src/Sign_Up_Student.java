import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


class Sign_Up_Student extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
	JTextField tf1,tf2,tf3,tf4,tf5;
	JRadioButton r1,r2,r3,r4,r5;
	JButton b;
	JComboBox c1,c2,c3;
	String c;
	
	
	public Sign_Up_Student()
	{
		super("SIGN UP AS STUDENT-PAGE 1");
		
		l1 = new JLabel("STUDENT SIGN UP");
		l1.setFont(new Font("Arial",Font.BOLD,25));
		
		l2 = new JLabel("Enter Personal Details");
		l2.setFont(new Font("Raleway",Font.PLAIN,20));
		
		l3 = new JLabel("Name:");
		l3.setFont(new Font("Raleway",Font.BOLD,20));
		
		l4 = new JLabel("Phone Number:");
		l4.setFont(new Font("Raleway",Font.BOLD,20));
		
		l5 = new JLabel("Date Of Birth:");
		l5.setFont(new Font("Raleway",Font.BOLD,20));
		
		l6 = new JLabel("Roll Number:");
		l6.setFont(new Font("Raleway",Font.BOLD,20));
		
		l7 = new JLabel("Gender:");
		l7.setFont(new Font("Raleway",Font.BOLD,20));
		
		l8 = new JLabel("Vaccination Status:");
		l8.setFont(new Font("Raleway",Font.BOLD,20));
		
		l9 = new JLabel("State:");
		l9.setFont(new Font("Raleway",Font.BOLD,20));
		
		l10 = new JLabel("City:");
		l10.setFont(new Font("Raleway",Font.BOLD,20));
		
		l11 = new JLabel("Date");
		l11.setFont(new Font("Raleway",Font.BOLD,16));
		
		l12 = new JLabel("Month");
		l12.setFont(new Font("Raleway",Font.BOLD,16));
		
		l13 = new JLabel("Year");
		l13.setFont(new Font("Raleway",Font.BOLD,16));
		
		tf1 = new JTextField(20);
		tf1.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf2 = new JTextField(20);
		tf2.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf3 = new JTextField(20);
		tf3.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf4 = new JTextField(20);
		tf4.setFont(new Font("Arial",Font.PLAIN,18));
		
		tf5 = new JTextField(20);
		tf5.setFont(new Font("Arial",Font.PLAIN,18));
		
		b = new JButton("Next");
		b.setFont(new Font("Raleway",Font.BOLD,14));
		b.setBackground(Color.BLACK);
		b.setForeground(Color.WHITE);
		
		r1 = new JRadioButton("Male");
		r1.setFont(new Font("Raleway",Font.BOLD,14));
		r1.setBackground(Color.WHITE);
		
		r2 = new JRadioButton("Female");
		r2.setFont(new Font("Raleway",Font.BOLD,14));
		r2.setBackground(Color.WHITE);
		
		r3 = new JRadioButton("Full");
		r3.setFont(new Font("Raleway",Font.BOLD,14));
		r3.setBackground(Color.WHITE);
		
		r4 = new JRadioButton("Partial");
		r4.setFont(new Font("Raleway",Font.BOLD,14));
		r4.setBackground(Color.WHITE);
		
		r5 = new JRadioButton("Not Vaccinated");
		r5.setFont(new Font("Raleway",Font.BOLD,14));
		r5.setBackground(Color.WHITE);
		
		String date[] = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","16","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
		c1 = new JComboBox(date);
		c1.setBackground(Color.WHITE);
		
		String Month[] = {"January","February","March","April","May","June","July","August","September","October","November","December"};
		c2 = new JComboBox(Month);
		c2.setBackground(Color.WHITE);
		
		String Year[] = {"1998","1999","2000","2001","2002","2003","2004"};
		c3 = new JComboBox(Year);
		c3.setBackground(Color.WHITE);
		
		setLayout(null);
		
		l1.setBounds(370,0, 250,150);		//student sign up
		add(l1);
		
		l2.setBounds(385, 60, 250, 100);		//enter personal details
		add(l2);
		
		l3.setBounds(180, 130, 100, 100);		//name
		add(l3);
		
		l4.setBounds(180, 170, 150, 100);		//phone number
		add(l4);
		
		l5.setBounds(180, 210, 200, 100);		//date of birth
		add(l5);
		
		l6.setBounds(180, 250, 200, 100);		//roll number
		add(l6);
		
		l7.setBounds(180, 290, 100, 100);		//gender
		add(l7);
		
		l8.setBounds(180, 410, 200, 100);		//vaccination status
		add(l8);
		
		l9.setBounds(180, 330, 100, 100);		//state
		add(l9);
		
		l10.setBounds(180, 370, 100, 100);		//city
		add(l10);
		
		l11.setBounds(430, 220, 50, 75);		//date
		add(l11);
		
		tf1.setBounds(430, 163,350,28);
		add(tf1);
		
		tf2.setBounds(430, 205, 350, 28);
		add(tf2);
		
		tf3.setBounds(430, 287, 350, 28);
		add(tf3);
		
		c1.setBounds(472, 248, 50, 20);			//date
		add(c1);
		
		l12.setBounds(535, 220, 50, 75);		//month
		add(l12);
		
		c2.setBounds(585, 248, 85, 20);		    //month
		add(c2);
		
		l13.setBounds(680, 220, 50, 75);		//year
		add(l13);
		
		c3.setBounds(720, 248, 60, 20);			//year
		add(c3);
		
		r1.setBounds(460, 330, 70, 20);			//male
		add(r1);
		
		r2.setBounds(650, 330, 80, 20);			//female
		add(r2);
		
		r3.setBounds(430, 450, 70, 20);			//full
		add(r3);
		
		r4.setBounds(530, 450, 80, 20);			//partially
		add(r4);
		
		r5.setBounds(650, 450, 139, 20);		//not
		add(r5);
		
		tf4.setBounds(430, 365, 350, 28);
		add(tf4);
		
		tf5.setBounds(430, 410, 350, 28);
		add(tf5);
		
		b.setBounds(430, 550, 100, 30);
		add(b);
		
		b.addActionListener(this);
		
		getContentPane().setBackground(Color.WHITE);
		
		setLocation(150,10);
		setSize(1000,700);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) 
	{
		
		String a = tf1.getText();		//name
		String b = tf2.getText();		//phone number
		
		String ac = (String)c1.getSelectedItem();		//date
		String bc = (String)c2.getSelectedItem();		//month
		String cc = (String)c3.getSelectedItem();		//year
		
		c = tf3.getText();		//roll number
		
		String d=null;
		if(r1.isSelected()) 
		{
			d = "Male";
		}
		else if(r2.isSelected())
		{
			d = "Female";
		}
		
		String e = tf4.getText();		//state
		String f = tf5.getText();		//city
		
		String g=null;
		if(r3.isSelected()) 
		{
			g = "Fully Vaccinated";
		}
		else if(r4.isSelected()) 
		{
			g = "Partially Vaccinated";
		}
		else if(r5.isSelected()) 
		{
			g = "Not Vaccinated";
		}
		
		try 
		{
			if(tf1.getText().equals("")||tf2.getText().equals("")||tf3.getText().equals("")||tf4.getText().equals("")||tf5.getText().equals("")) 
			{
				JOptionPane.showMessageDialog(null, "Fill all the required Data");
			}
			else 
			{
				conn c1 = new conn();
				String q = "INSERT INTO student1 VALUES('"+a+"','"+b+"','"+ac+"','"+bc+"','"+cc+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"');";
				c1.s.executeUpdate(q);
				
				new Sign_Up_Student_2().setVisible(true);
				setVisible(false);
			}
		}
		catch (Exception ex) 
		{
			System.err.println("error" + ex);
		}
	}
	public static void main(String[] args) 
	{
		new Sign_Up_Student().setVisible(true);
	}
}


	