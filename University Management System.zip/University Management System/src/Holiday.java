import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Holiday extends JFrame implements ActionListener
{
	JTable t1;
	JButton b1,b2;
	String x[] = {"S.NO","HOLIDAY","DATE","SAKA DATE","DAY"};
	String y [][] = new String[20][6] ;
	int i=0,j=0;
	public Holiday() 
	{
		super("LIST OF INSTITUTE GAZETTED HOLIDAY DURING THE YEAR-2021");
		
		setLocation(300,170);
		setSize(800,343);
		
		try 
		{
			conn c1 = new conn();
			String s1 = "select * from holiday;";
			ResultSet rs = c1.s.executeQuery(s1);
			while(rs.next()) 
			{
				y[i][j++] = rs.getString("ID");
				y[i][j++] = rs.getString("Holiday");
				y[i][j++] = rs.getString("Date");
				y[i][j++] = rs.getString("Date");
				y[i][j++] = rs.getString("SakaDate");
				y[i][j++] = rs.getString("Day");
				i++;
				j=0;
				
			}
			t1 = new JTable(y,x);
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		b1 = new JButton("PRINT");
		b1.setFont(new Font("Raleway",Font.BOLD,14));
		b1.setBackground(Color.lightGray);
		b1.setForeground(Color.RED);
		add(b1,"South");
		
		JScrollPane sp = new JScrollPane(t1);
		add(sp);
		b1.addActionListener(this);
		
		
		
		getContentPane().setBackground(Color.white);
		
		
		setVisible(true);
		
	
	}
	public void  actionPerformed(ActionEvent ae) 
	{
		try 
		{
			t1.print();
		}catch(Exception e) 
		{
			System.out.println(e);
		}
	}

	public static void main(String[] args) 
	{
		new Holiday().setVisible(true);

	}

}
